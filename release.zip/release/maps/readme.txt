地图txt中，格式必须是数字和,组成的长方形矩阵，且不能有任何多余的行。
具体请参考map1

地块类型：
    0: Road             可以行走
    1: Wall             墙壁
    2: Box              箱子
    3: Point            目标点
    4: InPoint          上面有箱子的目标点
    5: Empty            墙内
    6: Player           玩家
    7: PlayerInPoint    玩家在目标点上